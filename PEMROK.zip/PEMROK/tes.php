<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Genshin Community</title>
    <link rel="shortcut icon" type="image/png" href="image/Logo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/lib..." integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="css/tex.css">
</head>

<body>

    <header>
        <h2 class="logo"><img src="image/home.png" alt="homepage" width="50" height="50"></h2>
        <nav>
            <a href="#">Home</a>
            <a href="#">Gallery</a>
            <a href="#">About Us</a>
            <a href="#">Contact Us</a>
            <button class="popup-login">login</button>
        </nav>
    </header>

    <div class="iframe-container">
        <div class="gradientbg"></div>
        <iframe src="https://www.youtube.com/embed/4xg7ndmTcZ8?autoplay=1&mute=1&loop=1&playlist=4xg7ndmTcZ8" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
    </div>

    <div class="wrapper">
        <span class="close"><i class="fa-solid fa-xmark"></i></span>
        <div class="form-box login">
            <h2>Login</h2>
            <form action="#" method="post">
                <div class="form-input">
                    <span class="icon"><i class="fa-solid fa-envlope"></i></span>
                    <input type="email" name="email" required>
                    <label>Email/Username</label>
                </div>
                <div class="form-input">
                    <span class="icon"><i class="fa-solid fa-lock"></i></span>
                    <input type="password" name="password" required>
                    <label>Password</label>
                </div>
                <div class="remember-forgot">
                    <label><input type="checkbox" name="remember"> Remember me</label>
                    <a href="#">Forgot Password</a>
                </div>
                <button type="sumbit" class="btn">Login</button>
                <div class="login-register">
                    <p>Don't have an account? <a href="#" class="register-link">Register</a></p>
                </div>
            </form>
        </div>
        <div class="form-box register">
            <h2>Registrasion</h2>
            <form action="#" method="post">
                <div class="form-input">
                    <span class="icon"><i class="fa-solid fa-user"></i></span>
                    <input type="text" name="username" required>
                    <label>Username</label>
                </div>
                <div class="form-input">
                    <span class="icon"><i class="fa-solid fa-envelope"></i></span>
                    <input type="email" name="email" required>
                    <label>Email</label>
                </div>
                <div class="form-input">
                    <span class="icon"><i class="fa-solid fa-lock"></i></span>
                    <input type="password" name="password" required>
                    <label>Password</label>
                </div>
                <div class="remember-forgot">
                    <label><input type="checkbox"> I accept the <a href="#" class register-link>Terms of Use</a> & <a href="#" class register-link>Privacy Policy</a></label>
                </div>
                <button type="sumbit" class="btn">Login</button>
                <div class="login-register">
                    <p>Already have an account? <a href="#" class="register-link">Login</a></p>
                </div>
            </form>
        </div>
    </div>
    <script type="text/javascript">
        const wrapper = document.querySelector('.wrapper');
        const loginlink = document.querySelector('login-link');
        const registerlink = document.querySelector('regster-link');
        const btnpopup = document.querySelector('popup-login');

        registerlink.addEventListener('click', ()=> {
            wrapper.classList.add('active');
        });
        loginlink.addEventListener('click', ()=> {
            wrapper.classList.remove('active');
        })
        btnpopup.addEventListener('click', ()=> {
            wrapper.classList.add('active-popup');
        })
    </script>
</body>