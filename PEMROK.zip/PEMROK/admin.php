<?php include 'db.php'; ?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="shortcut icon" type="image/png" href="image/Logo.png">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/hammerjs@2.0.8"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-zoom@1.0.0"></script>
    <link rel="stylesheet" type="text/css" href="css/styleadmin.css">
</head>
<body>
<div class="container">
    <h1>Admin Page</h1>
    
    <!-- Form Tambah Video -->
    <h2>Add Video</h2>
    <form action="add_video.php" method="post">
        Thumbnail URL: <input type="text" name="thumbnail"><br>
        Video URL: <input type="text" name="video_url"><br>
        Title: <input type="text" name="title"><br>
        Genre: <input type="text" name="genre"><br>
        Description: <textarea name="description"></textarea><br>
        <input type="submit" value="Add Video">
    </form>
    
    <!-- Daftar Video -->
    <h2>Video List</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Thumbnail</th>
            <th>Video URL</th>
            <th>Title</th>
            <th>Genre</th>
            <th>Description</th>
            <th>Action</th>
        </tr>
        <?php
        $result = $conn->query("SELECT * FROM videos");
        while($row = $result->fetch_assoc()) {
            echo "<tr>
                <td>{$row['id']}</td>
                <td><img src='{$row['thumbnail']}'></td>
                <td>{$row['video_url']}</td>
                <td>{$row['title']}</td>
                <td>{$row['genre']}</td>
                <td>{$row['description']}</td>
                <td>
                    <a href='edit_video.php?id={$row['id']}'>Edit</a> | 
                    <a href='delete_video.php?id={$row['id']}'>Delete</a>
                </td>
            </tr>";
        }
        ?>
    </table>
</div>
</body>
</html>
