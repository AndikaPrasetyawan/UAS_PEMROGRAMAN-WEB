<?php include 'db.php'; ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AMVID Community</title>
    <link rel="shortcut icon" type="image/png" href="image/Logo.png">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/hammerjs@2.0.8"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-zoom@1.0.0"></script>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div class="container">
        <nav class="navbar">
            <a href="index.php" class="logo">
                <img src="image/home.png" alt="Logo">
            </a>
            <ul class="nav-links">
                <li><a href="index.php">Home</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
            <?php
            if (isset($_SESSION['userid'])) :
            ?>
                <a href="logout.php" id="loginBtn" class="login-link">Logout</a>
            <?php
            else :
            ?>
                <a href="#" id="loginBtn" class="login-link">Login</a>
            <?php endif;
            ?>
        </nav>
        <div class="filters">
            <select>
                <option>All Type</option>
                <!-- Add more filter options here -->
            </select>
            <select>
                <option>All Style</option>
                <!-- Add more filter options here -->
            </select>
        </div>
        <div class="videos">
            <?php
            $result = $conn->query("SELECT * FROM videos");
            while ($row = $result->fetch_assoc()) {
                echo "
                <div class='video-card'>
                    <a href='video.php?id={$row['id']}' target='_blank'>
                        <img src='{$row['thumbnail']}' alt='Video Thumbnail'>
                    </a>
                    <div class='video-info'>
                        <div class='video-title'>{$row['title']}</div>
                        <div>
                            <span class='tag'>{$row['genre']}</span>
                        </div>
                        <div class='video-description'>By: {$row['description']}</div>
                        <div class='video-meta'>";
                if (isset($row['date'])) {
                    echo "<span>{$row['date']}</span>";
                }
                echo "
                        </div>
                    </div>
                </div>";
            }
            ?>
        </div>
    </div>
</body>

</html>
