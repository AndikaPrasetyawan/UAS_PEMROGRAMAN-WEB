<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Page</title>
    <link rel="stylesheet" href="css/stylesprofile.css">
</head>
<body>
    <div class="container">
        <header>
            <nav>
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Gallery</a></li>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Contact Us</a></li>
                </ul>
            </nav>
        </header>
        <div class="profile">
            <div class="profile-info">
                <div class="profile-pic">
                    <img src="default-profile-pic.png" alt="Profile Picture">
                </div>
                <div class="profile-details">
                    <h2>fusakhu</h2>
                    <p>@fusakhu</p>
                    <button>Edit Profile</button>
                </div>
            </div>
            <div class="upload-section">
                <button>Upload Video</button>
            </div>
        </div>
        <div class="content">
            <div class="categories">
                <ul>
                    <li><a href="#">All Category</a></li>
                    <li><a href="#">Anime Music Video</a></li>
                    <li><a href="#">Game Music Video</a></li>
                    <li><a href="#">Manga Music Video</a></li>
                </ul>
            </div>
            <div class="no-results">
                <p>No results Found.</p>
            </div>
        </div>
    </div>
</body>
</html>
