<?php
session_start();

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['userid'])) {
    // Jika tidak ada sesi, arahkan ke halaman login
    header("Location: index.php");
    exit();
}

// Jika sesi ada, lanjutkan dengan menampilkan halaman index.php
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AMVID Community</title>
    <link rel="shortcut icon" type="image/png" href="image/Logo.png">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/hammerjs@2.0.8"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-zoom@1.0.0"></script>
    <link rel="stylesheet" href="css/style.css">
    <style>
    </style>
</head>
<body>
<div class="container">
        <nav class="navbar">
            <a href="index.php" class="logo">
                <img src="image/home.png" alt="Logo">
            </a>
            <ul class="nav-links">
                <li><a href="index.php">Home</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
            <?php
            if (isset($_SESSION['userid'])) :
            ?>
                <a href="logout.php" id="loginBtn" class="login-link">Logout</a>
            <?php
            else :
            ?>
                <a href="#" id="loginBtn" class="login-link">Login</a>
            <?php endif;
            ?>
        </nav>
        <div class="tajuk">
            AMVID <br>COMMUNITY
            <div class="destajuk">
                The Indonesian AMV Community is an AMV (Anime Music Video) community created
                to facilitate video makers (editors) in expressing their creativity by
                making music videos using a collection of anime clips.
            </div>
        </div>
    </div>
    </div>
    <div class="content">
    </div>
    <div class="iframe-container">
        <div class="gradientbg"></div>
        <h1>MOST PLAYED</h1>
        <div class="videos">
            <div class="video-card">
                <a href="aku-ingin-kita-berpisah.php" target="_blank">
                    <img src="https://i3.ytimg.com/vi/aQTHN_9IJvA/maxresdefault.jpg" alt="Video Thumbnail">
                </a>
                <div class="video-info">
                    <div class="video-title">[IC] Aku Ingin Kita Bepisah </div>
                    <div>
                        <span class="tag">AMV</span>
                        <span class="tag">Romance</span>
                    </div>
                    <div class="video-description">By: Sebuah Sirkel</div>
                    <div class="video-meta">
                        <span>28 Jun 2024</span>
                    </div>
                </div>
            </div>
            <div class="video-card">
                <img src="https://i3.ytimg.com/vi/x2joHZ9MPC4/maxresdefault.jpg" alt="Video Thumbnail">
                <div class="video-info">
                    <div class="video-title">「MEP」- Strong 「 1st Anniversary !! 」</div>
                    <div>
                        <span class="tag">AMV</span>
                        <span class="tag">Flow-FX</span>
                    </div>
                    <div class="video-description">By: Haikasu Team</div>
                    <div class="video-meta">
                        <span>26 Jun 2024</span>
                    </div>
                </div>
            </div>
            <div class="video-card">
                <img src="https://i3.ytimg.com/vi/cvy   0y-7nkNs/maxresdefault.jpg" alt="Video Thumbnail">
                <div class="video-info">
                    <div class="video-title">「MEP」Pieces of You</div>
                    <div>
                        <span class="tag">AMV</span>
                        <span class="tag">Action</span>
                    </div>
                    <div class="video-description"> By : Kigen Team</div>
                    <div class="video-meta">
                        <span>17 Jun 2024</span>
                    </div>
                </div>
            </div>
            <div class="video-card">
                <img src="https://i3.ytimg.com/vi/KeX6IaQWH-s/maxresdefault.jpg" alt="Video Thumbnail">
                <div class="video-info">
                    <div class="video-title">[ amv ] my escape</div>
                    <div>
                        <span class="tag">AMV</span>
                        <span class="tag">Action</span>
                    </div>
                    <div class="video-description">By: tsukimvv._</div>
                    <div class="video-meta">
                        <span>13 Jun 2024</span>
                    </div>
                </div>
            </div>
            <iframe src="https://www.youtube.com/embed/4xg7ndmTcZ8?autoplay=1&mute=1&loop=1&playlist=4xg7ndmTcZ8" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </div>
        <h1>RECENTLY ADDED</h1>
        <div class="videos">
            <div class="video-card">
                <a href="aku-ingin-kita-berpisah.php" target="_blank">
                    <img src="https://i3.ytimg.com/vi/vJjSpBVT9cI/maxresdefault.jpg" alt="Video Thumbnail">
                </a>
                <div class="video-info">
                    <div class="video-title">are you here forever?</div>
                    <div>
                        <span class="tag">AMV</span>
                        <span class="tag">Romance</span>
                    </div>
                    <div class="video-description">By: HUM4N</div>
                    <div class="video-meta">
                        <span>28 Jun 2024</span>
                    </div>
                </div>
            </div>
            <div class="video-card">
            <img src="https://i3.ytimg.com/vi/W8HPH5vrqgc/maxresdefault.jpg" alt="Video Thumbnail">
                <div class="video-info">
                    <div class="video-title">trying to feel alive</div>
                    <div>
                        <span class="tag">AMV</span>
                        <span class="tag">Flow-FX</span>
                    </div>
                    <div class="video-description">By: Haikasu Team</div>
                    <div class="video-meta">
                        <span>26 Jun 2024</span>
                    </div>
                </div>
            </div>
            <div class="video-card">
                <img src="https://i3.ytimg.com/vi/l2fdiiyqh6U/maxresdefault.jpg" alt="Video Thumbnail">
                <div class="video-info">
                    <div class="video-title">「Onii」mep - strong one direction</div>
                    <div>
                        <span class="tag">AMV</span>
                        <span class="tag">Action</span>
                    </div>
                    <div class="video-description"> By : Kigen Team</div>
                    <div class="video-meta">
                        <span>17 Jun 2024</span>
                    </div>
                </div>
            </div>
            <div class="video-card">
            <img src="https://i3.ytimg.com/vi/OenN22qwDPo/maxresdefault.jpg" alt="Video Thumbnail">
                <div class="video-info">
                    <div class="video-title">「MEP」 Into you</div>
                    <div>
                        <span class="tag">AMV</span>
                        <span class="tag">Action</span>
                    </div>
                    <div class="video-description">By: tsukimvv._</div>
                    <div class="video-meta">
                        <span>13 Jun 2024</span>
                    </div>
                </div>
            </div>
            <script src="javascript/amv.js"></script>
</body>

</html>
