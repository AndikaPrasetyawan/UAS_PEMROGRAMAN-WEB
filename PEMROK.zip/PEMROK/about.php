<?php
session_start();
if (isset($_SESSION['auth_id'])) {
    header("Location: http://{$_SERVER['HTTP_HOST']}");
    die();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link rel="shortcut icon" type="image/png" href="image/Logo.png">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/hammerjs@2.0.8"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-zoom@1.0.0"></script>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            background: url('image/bg.png') no-repeat center center fixed;
            background-size: cover;
            color: white;
            display: flex;
            justify-content: left;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .navbar {
            background-color: black;
            width: 100%;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }

        .nav-links a {
            color: white;
        }

        .login-link {
            color: white;
        }

        .about-us-section {
            color: white;
            text-align: center;
            /* Mengatur teks di tengah secara horizontal */
            padding: 0 10px;
            /* Memberikan ruang di sisi kiri dan kanan yang lebih sedikit */
        }

        .about-us-section h2,
        .about-us-section p {
            color: white;
            text-align: left;
            /* Mengatur teks di kiri */
        }

        .container {
            width: 100%;
            max-width: 800px;
            /* Membatasi lebar konten agar tetap terjaga tata letaknya */
        }

        h2 {
            font-size: 70px;
            margin-left: 20%;
        }

        p {
            margin-left: 20%;
            font-size: 100%;
        }

        .col-md-12 {
            margin-top: 50%;

        }

        h3 {
            margin-right: 42%;
        }
    </style>
</head>

<body>
    <div class="container">
    <nav class="navbar">
            <a href="index.php" class="logo">
                <img src="image/home.png" alt="Logo">
            </a>
            <ul class="nav-links">
                <li><a href="index.php">Home</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
            <?php
            if (isset($_SESSION['userid'])) :
            ?>
                <a href="logout.php" id="loginBtn" class="login-link">Logout</a>
            <?php
            else :
            ?>
                <a href="#" id="loginBtn" class="login-link">Login</a>
            <?php endif;
            ?>
        </nav>

        <!-- About Us Section -->
        <section class="about-us-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="mb-4">About Us</h2>
                        <h3>AMV Indonesia </h3>
                    </div>
                    <div desc>
                        <br>
                        <p>
                            AMV merupakan singkatan dari kata "Anime Music Video" seperti namanya, AMV merupakan gabungan beberapa klip Anime yang di gabungkan menjadi satu video. Yang di iringi dengan lantunan musik. klip - klip yang di ambil dari setiap anime biasanya klip yang epic, seperti adegan pertarungan, mode santai, ataupun juga adegan saat melakukan sesuatu.
                        </p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Bootstrap JS and dependencies -->
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>