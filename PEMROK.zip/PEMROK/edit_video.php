<?php
include 'db.php';

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM videos WHERE id=$id");
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Video</title>
    <link rel="stylesheet" type="text/css" href="css/styleadmin.css">
</head>
<body>
<div class="container">
    <h1>Edit Video</h1>
    <form action="update_video.php" method="post">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        Thumbnail URL: <input type="text" name="thumbnail" value="<?php echo $row['thumbnail']; ?>"><br>
        Video URL: <input type="text" name="video_url" value="<?php echo $row['video_url']; ?>"><br>
        Title: <input type="text" name="title" value="<?php echo $row['title']; ?>"><br>
        Genre: <input type="text" name="genre" value="<?php echo $row['genre']; ?>"><br>
        Description: <textarea name="description"><?php echo $row['description']; ?></textarea><br>
        <input type="submit" value="Update Video">
    </form>
</div>
</body>
</html>
