<?php
include 'db.php';

$id = $_POST['id'];
$thumbnail = $_POST['thumbnail'];
$video_url = $_POST['video_url'];
$title = $_POST['title'];
$genre = $_POST['genre'];
$description = $_POST['description'];

$sql = "UPDATE videos SET thumbnail='$thumbnail', video_url='$video_url', title='$title', genre='$genre', description='$description' WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();

header("Location: admin.php");
?>
