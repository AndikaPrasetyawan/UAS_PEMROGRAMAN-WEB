<?php
include('koneksi.php');
$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Basic validation
    if (empty($username) || empty($email) || empty($password)) {
        $error = 'All fields are required.';
    } else {
        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Prepare the SQL statement to prevent SQL injection
        $stmt = $conn->prepare("INSERT INTO users (username, email, katasandi) VALUES (?, ?, ?)");

        // Check if the statement was prepared correctly
        if ($stmt === false) {
            $error = "Error in preparing statement: " . $conn->error;
        } else {
            // Use $hashedPassword for the katasandi field
            $stmt->bind_param("sss", $username, $email, $hashedPassword);

            // Execute the statement
            if ($stmt->execute() === TRUE) {
                header("Location: login.php");
                exit();
            } else {
                $error = "Error: " . $stmt->error;
            }

            // Close the statement
            $stmt->close();
        }
    }

    // Close the connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Register</title>
    <link rel="stylesheet" type="text/css" href="css/styleregis.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            padding: 105px;
            border-radius: 31px;
            background: transparent;
            backdrop-filter: blur(20px);
            box-shadow: 0 0 30px rgba(0, 0, 0, 0.5);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: white;
            font-size: 51px;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        input[type="submit"] {
            background-color: darkblue;
            color: #fff;
            border: none;
            padding: 10px;
            width: 100%;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #fff;
            color: blue;
        }

        .error {
            color: red;
            text-align: center;
            margin-bottom: 10px;
        }

        .remember-forgot {
            margin-top: 10px;
        }

        .register-link {
            color: #28a745;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Register</h2>
        <?php
        if (!empty($error)) {
            echo '<p class="error">' . $error . '</p>';
        }
        ?>
        <form method="post" action="">
            <input type="text" name="username" placeholder="Username" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <div class="remember-forgot">
                <label><input type="checkbox" required> I accept the <a href="#" class="register-link">Terms of Use</a> & <a href="#" class="register-link">Privacy Policy</a></label>
            </div>
            <input type="submit" value="Register">
        </form>
    </div>
</body>

</html>