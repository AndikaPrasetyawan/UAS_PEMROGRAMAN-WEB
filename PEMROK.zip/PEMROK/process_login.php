<?php
session_start();
include('koneksi.php');  // Atur koneksi ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Lakukan query untuk mendapatkan hash password dari database
    $stmt = $conn->prepare("SELECT id, username, katasandi FROM users WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc()[0];
        // Verifikasi password
        if (password_verify($password, $row['katasandi'])) {
            // Login berhasil, atur sesi
            $_SESSION['userid'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            // Arahkan ke halaman utama atau halaman lain yang sesuai
            header("Location: index.php");
            exit();
        } else {
            // Tampilkan pesan jika password salah
            echo "Password salah.";
        }
    } else {
        // Tampilkan pesan jika username tidak ditemukan
        echo "Username tidak ditemukan.";
    }

    // Tutup statement dan koneksi
    $stmt->close();
    $conn->close();
}
?>
