<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video Page</title>
    <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        background-color: #000;
        color: #fff;
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        display: flex;
        flex-direction: column;
        min-height: 100vh;
    }

    .navbar {
        display: flex;
        align-items: center;
        padding: 10px 20px;
        background-color: #000000;
        z-index: 3;
        width: 100%;
    }

    .navbar .logo img {
        height: 50px;
    }

    .nav-links {
        list-style: none;
        display: flex;
        margin-right: auto;
        text-decoration: none;
    }

    .nav-links li {
        margin-left: 20px;
    }

    .nav-links a {
        text-decoration: none;
        color: white;
        padding: 5px 10px;
        transition: background-color 0.3s;
    }

    .login-link {
        color: #fff;
        text-decoration: none;
        cursor: pointer;
    }

    .main-content {
        flex: 1;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .container {
        width: 80%;
        max-width: 1200px;
        display: flex;
        gap: 20px;
        padding-top: 20px;
    }

    iframe {
        width: 60%;
        height: 450px;
        border: none;
    }

    /* .video-info {
        width: 40%;
        text-align: left;
    } */

    .video-info h2 {
        margin: 0;
    }

    .video-info p {
        margin: 5px 0;
    }

    .video-info a {
        color: #1e90ff;
        text-decoration: none;
    }

    .social-links {
        margin-top: 10px;
    }

    .social-links a {
        margin-right: 10px;
        color: #1e90ff;
        text-decoration: none;
    }

    .video-detail {
    display: flex;
    justify-content: center;
    flex-direction: column;
    margin-top: 20px;
    text-align: center;
}

.video-detail h1 {
    margin-bottom: 10px;
}

.video-detail iframe {
    width: 80%;
    height: 450px;
    border: none;
    margin-bottom: 20px;
}

/* .video-info {
    width: 80%;
    max-width: 600px;
    text-align: left;
} */

    </style>
</head>

<body>
    <nav class="navbar">
        <a href="index.php" class="logo">
            <img src="image/home.png" alt="Logo">
        </a>
        <ul class="nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="gallery.php">Gallery</a></li>
            <li><a href="about.php">About Us</a></li>
            <li><a href="contact.php">Contact Us</a></li>
        </ul>
        <a href="#" id="loginBtn" class="login-link">Login</a>
    </nav>
        <div class="video-detail">
            <?php
            if (isset($_GET['id'])) {
                $id = $_GET['id'];
                $result = $conn->query("SELECT * FROM videos WHERE id='$id'");
                if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    echo "
                    <h1>{$row['title']}</h1>
                    <div>
                        <iframe src='{$row['video_url']}' frameborder='0' allowfullscreen></iframe>
                    </div>
                    <div class='video-info'>
                        <p><strong>Genre:</strong> {$row['genre']}</p>
                        <p><strong>Description:</strong> {$row['description']}</p>";
                    if (isset($row['date'])) {
                        echo "<p><strong>Date:</strong> {$row['date']}</p>";
                    }
                    echo "</div>";
                } else {
                    echo "<p>Video not found.</p>";
                }
            } else {
                echo "<p>No video ID provided.</p>";
            }
            ?>
        </div>
    </div>
</body>

</html>
