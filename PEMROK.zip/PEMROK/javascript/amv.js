document.getElementById('loginBtn').addEventListener('click', function () {
    document.getElementById('loginPopup').classList.add('show');
});

document.getElementById('closePopup').addEventListener('click', function () {
    document.getElementById('loginPopup').classList.remove('show');
});

window.addEventListener('click', function (event) {
    if (event.target == document.getElementById('loginPopup')) {
        document.getElementById('loginPopup').classList.remove('show');
    }
});

document.getElementById('regisnBtn').addEventListener('click', function () {
    document.getElementById('regisnPopup').classList.add('show');
});

document.getElementById('closePopup').addEventListener('click', function () {
    document.getElementById('regisPopup').classList.remove('show');
});

window.addEventListener('click', function (event) {
    if (event.target == document.getElementById('regisPopup')) {
        document.getElementById('regisPopup').classList.remove('show');
    }
});
