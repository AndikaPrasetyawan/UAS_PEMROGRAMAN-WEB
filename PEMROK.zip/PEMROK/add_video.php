<?php
include 'db.php';

$thumbnail = $_POST['thumbnail'];
$video_url = $_POST['video_url'];
$title = $_POST['title'];
$genre = $_POST['genre'];
$description = $_POST['description'];

$sql = "INSERT INTO videos (thumbnail, video_url, title, genre, description)
VALUES ('$thumbnail', '$video_url', '$title', '$genre', '$description')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

header("Location: admin.php");
?>
